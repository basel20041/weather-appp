# WeatherApp

A new Flutter project.

## Getting Started
![dZdS0M](https://github.com/user-attachments/assets/d6cfefc7-935f-4297-bea8-021bee24fef8)


